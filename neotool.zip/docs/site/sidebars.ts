
export default {
  docs: [
    'intro',
    'architecture'
  ]
};
