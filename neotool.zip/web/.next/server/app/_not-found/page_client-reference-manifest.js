globalThis.__RSC_MANIFEST = globalThis.__RSC_MANIFEST || {};
globalThis.__RSC_MANIFEST["/_not-found/page"] = {
  moduleLoading: { prefix: "/_next/", crossOrigin: null },
  ssrModuleMapping: {
    1177: { "*": { id: "6021", name: "*", chunks: [], async: false } },
    1308: { "*": { id: "2863", name: "*", chunks: [], async: false } },
    2424: { "*": { id: "2834", name: "*", chunks: [], async: false } },
    5821: { "*": { id: "5810", name: "*", chunks: [], async: false } },
    5904: { "*": { id: "8375", name: "*", chunks: [], async: false } },
    6764: { "*": { id: "6562", name: "*", chunks: [], async: false } },
    8192: { "*": { id: "1635", name: "*", chunks: [], async: false } },
    9430: { "*": { id: "7396", name: "*", chunks: [], async: false } },
    9454: { "*": { id: "1914", name: "*", chunks: [], async: false } },
  },
  edgeSSRModuleMapping: {},
  clientModules: {
    "/Users/salomax/src/neotool/neotool/web/node_modules/.pnpm/next@14.2.5_@babel+core@7.28.4_@opentelemetry+api@1.9.0_@playwright+test@1.45.3_react-d_81eab96a839e36964fe012b9257363f7/node_modules/next/dist/client/components/app-router.js":
      { id: 5904, name: "*", chunks: [], async: false },
    "/Users/salomax/src/neotool/neotool/web/node_modules/.pnpm/next@14.2.5_@babel+core@7.28.4_@opentelemetry+api@1.9.0_@playwright+test@1.45.3_react-d_81eab96a839e36964fe012b9257363f7/node_modules/next/dist/esm/client/components/app-router.js":
      { id: 5904, name: "*", chunks: [], async: false },
    "/Users/salomax/src/neotool/neotool/web/node_modules/.pnpm/next@14.2.5_@babel+core@7.28.4_@opentelemetry+api@1.9.0_@playwright+test@1.45.3_react-d_81eab96a839e36964fe012b9257363f7/node_modules/next/dist/client/components/client-page.js":
      { id: 1177, name: "*", chunks: [], async: false },
    "/Users/salomax/src/neotool/neotool/web/node_modules/.pnpm/next@14.2.5_@babel+core@7.28.4_@opentelemetry+api@1.9.0_@playwright+test@1.45.3_react-d_81eab96a839e36964fe012b9257363f7/node_modules/next/dist/esm/client/components/client-page.js":
      { id: 1177, name: "*", chunks: [], async: false },
    "/Users/salomax/src/neotool/neotool/web/node_modules/.pnpm/next@14.2.5_@babel+core@7.28.4_@opentelemetry+api@1.9.0_@playwright+test@1.45.3_react-d_81eab96a839e36964fe012b9257363f7/node_modules/next/dist/client/components/error-boundary.js":
      { id: 8192, name: "*", chunks: [], async: false },
    "/Users/salomax/src/neotool/neotool/web/node_modules/.pnpm/next@14.2.5_@babel+core@7.28.4_@opentelemetry+api@1.9.0_@playwright+test@1.45.3_react-d_81eab96a839e36964fe012b9257363f7/node_modules/next/dist/esm/client/components/error-boundary.js":
      { id: 8192, name: "*", chunks: [], async: false },
    "/Users/salomax/src/neotool/neotool/web/node_modules/.pnpm/next@14.2.5_@babel+core@7.28.4_@opentelemetry+api@1.9.0_@playwright+test@1.45.3_react-d_81eab96a839e36964fe012b9257363f7/node_modules/next/dist/client/components/layout-router.js":
      { id: 2424, name: "*", chunks: [], async: false },
    "/Users/salomax/src/neotool/neotool/web/node_modules/.pnpm/next@14.2.5_@babel+core@7.28.4_@opentelemetry+api@1.9.0_@playwright+test@1.45.3_react-d_81eab96a839e36964fe012b9257363f7/node_modules/next/dist/esm/client/components/layout-router.js":
      { id: 2424, name: "*", chunks: [], async: false },
    "/Users/salomax/src/neotool/neotool/web/node_modules/.pnpm/next@14.2.5_@babel+core@7.28.4_@opentelemetry+api@1.9.0_@playwright+test@1.45.3_react-d_81eab96a839e36964fe012b9257363f7/node_modules/next/dist/client/components/not-found-boundary.js":
      { id: 6764, name: "*", chunks: [], async: false },
    "/Users/salomax/src/neotool/neotool/web/node_modules/.pnpm/next@14.2.5_@babel+core@7.28.4_@opentelemetry+api@1.9.0_@playwright+test@1.45.3_react-d_81eab96a839e36964fe012b9257363f7/node_modules/next/dist/esm/client/components/not-found-boundary.js":
      { id: 6764, name: "*", chunks: [], async: false },
    "/Users/salomax/src/neotool/neotool/web/node_modules/.pnpm/next@14.2.5_@babel+core@7.28.4_@opentelemetry+api@1.9.0_@playwright+test@1.45.3_react-d_81eab96a839e36964fe012b9257363f7/node_modules/next/dist/client/components/render-from-template-context.js":
      { id: 5821, name: "*", chunks: [], async: false },
    "/Users/salomax/src/neotool/neotool/web/node_modules/.pnpm/next@14.2.5_@babel+core@7.28.4_@opentelemetry+api@1.9.0_@playwright+test@1.45.3_react-d_81eab96a839e36964fe012b9257363f7/node_modules/next/dist/esm/client/components/render-from-template-context.js":
      { id: 5821, name: "*", chunks: [], async: false },
    "/Users/salomax/src/neotool/neotool/web/app/not-found.tsx": {
      id: 9430,
      name: "*",
      chunks: ["160", "static/chunks/app/not-found-de68669c7b399123.js"],
      async: false,
    },
    "/Users/salomax/src/neotool/neotool/web/src/components/ClientProviders.tsx":
      {
        id: 9454,
        name: "*",
        chunks: ["185", "static/chunks/app/layout-ec3bffc18c4b3b7b.js"],
        async: false,
      },
    "/Users/salomax/src/neotool/neotool/web/app/page.tsx": {
      id: 1308,
      name: "*",
      chunks: ["931", "static/chunks/app/page-34793dd3f07a975a.js"],
      async: false,
    },
  },
  entryCSSFiles: {
    "/Users/salomax/src/neotool/neotool/web/": [],
    "/Users/salomax/src/neotool/neotool/web/app/not-found": [],
    "/Users/salomax/src/neotool/neotool/web/app/layout": [],
    "/Users/salomax/src/neotool/neotool/web/app/page": [],
    "/Users/salomax/src/neotool/neotool/web/app/_not-found/page": [],
  },
};
