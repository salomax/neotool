
# Terraform (esqueleto)

Este diretório é um *placeholder* para infraestrutura futura. Como o ambiente alvo não está definido (sem AWS),
mantenha os módulos desacoplados e reutilizáveis. Exemplos sugeridos:
- Provedor `kubernetes` para aplicar manifests.
- Provisionamento de repositório no GHCR.
- Gestão de secrets (SOPS + age, etc.).
