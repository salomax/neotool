package io.github.salomax.neotool.test.json

import io.micronaut.http.HttpResponse
import io.micronaut.json.JsonMapper

inline fun <reified T> JsonMapper.read(resp: HttpResponse<String>): T {
  require(resp.body.isPresent) { "Empty body" }
  val bytes = resp.body.get().toByteArray()
  return this.readValue(bytes, T::class.java)
}
