package io.github.salomax.neotool.example.test

import io.github.salomax.neotool.example.api.*
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.api.Tag
import org.junit.jupiter.api.TestInstance

/**
 * Integration Test Suite
 * 
 * This class serves as a documentation of all available integration tests.
 * To run all integration tests, use: ./gradlew testIntegration
 * 
 * Available test classes:
 * - ProductApiIntegrationTest: Tests for Product REST API endpoints
 * - CustomerApiIntegrationTest: Tests for Customer REST API endpoints  
 * - DashboardApiIntegrationTest: Tests for Dashboard REST API endpoints
 * - EventsApiIntegrationTest: Tests for Events REST API endpoints
 * - GraphQLApiIntegrationTest: Tests for GraphQL API endpoints
 */
@DisplayName("Integration Test Suite")
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@Tag("integration")
class IntegrationTestSuite {
    
    // This class serves as documentation and can be extended with additional test methods
    // if needed for cross-cutting concerns or setup/teardown operations
}
