package io.github.salomax.neotool.example.api

import io.github.salomax.neotool.example.test.TestDataBuilders
import io.github.salomax.neotool.test.assertions.shouldHaveNonEmptyBody
import io.github.salomax.neotool.test.assertions.shouldBeJson
import io.github.salomax.neotool.test.assertions.shouldBeSuccessful
import io.github.salomax.neotool.test.assertions.shouldHaveErrors
import io.github.salomax.neotool.test.http.exchangeAsString
import io.github.salomax.neotool.test.integration.BaseIntegrationTest
import io.github.salomax.neotool.test.integration.PostgresIntegrationTest
import io.github.salomax.neotool.test.json.read
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpStatus
import io.micronaut.http.MediaType
import io.micronaut.http.client.exceptions.HttpClientResponseException
import io.micronaut.test.extensions.junit5.annotation.MicronautTest
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.*
import org.junit.jupiter.api.assertThrows
import java.util.concurrent.CompletableFuture
import java.util.concurrent.TimeUnit

@MicronautTest(startApplication = true)
@DisplayName("GraphQL API Integration Tests")
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@Tag("integration")
@Tag("graphql")
@TestMethodOrder(MethodOrderer.Random::class) // Randomize test execution for better isolation
class GraphQLApiIntegrationTest : BaseIntegrationTest(), PostgresIntegrationTest {

    // Test data isolation helpers
    private fun uniqueSku() = "GRAPHQL-${System.currentTimeMillis()}-${Thread.currentThread().id}"
    private fun uniqueEmail() = "graphql-${System.currentTimeMillis()}@example.com"
    private fun uniqueName() = "GraphQL Test ${System.currentTimeMillis()}"

    @BeforeEach
    fun cleanDatabase() {
        // Clean state between tests for better isolation
        // This would typically clean test data
    }

    @Test
    @Order(1)
    fun `should query products via GraphQL`() {
        val query = TestDataBuilders.productsQuery()
        val request = HttpRequest.POST("/graphql", query)
            .contentType(MediaType.APPLICATION_JSON)
        
        httpClient.exchangeAsString(request)
          .shouldBeSuccessful()
          .shouldBeJson()
          .shouldHaveNonEmptyBody()
    }

    @Test
    @Order(2)
    fun `should query customers via GraphQL`() {
        val query = TestDataBuilders.customersQuery()
        val request = HttpRequest.POST("/graphql", query)
            .contentType(MediaType.APPLICATION_JSON)
        
        httpClient.exchangeAsString(request)
          .shouldBeSuccessful()
          .shouldBeJson()
          .shouldHaveNonEmptyBody()
    }

    @Test
    @Order(3)
    fun `should create product via GraphQL mutation`() {
        val mutation = TestDataBuilders.createProductMutation(
            name = uniqueName(),
            sku = uniqueSku(),
            priceCents = 25000L,
            stock = 20
        )

        val request = HttpRequest.POST("/graphql", mutation)
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
          .shouldHaveNonEmptyBody()

        val body = response.body.get()
        assertThat(body).contains("data")
        assertThat(body).doesNotContain("errors")
        
        // Verify the response structure
        val responseData = json.read<Map<String, Any>>(response)
        assertThat(responseData).containsKey("data")
    }

    @Test
    @Order(4)
    fun `should create customer via GraphQL mutation`() {
        val mutation = TestDataBuilders.createCustomerMutation(
            name = uniqueName(),
            email = uniqueEmail(),
            status = "ACTIVE"
        )

        val request = HttpRequest.POST("/graphql", mutation)
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
          .shouldHaveNonEmptyBody()

        val body = response.body.get()
        assertThat(body).contains("data")
        assertThat(body).doesNotContain("errors")
        
        // Verify the response structure
        val responseData = json.read<Map<String, Any>>(response)
        assertThat(responseData).containsKey("data")
    }

    @Test
    @Order(5)
    fun `should handle GraphQL query with variables`() {
        val query = TestDataBuilders.graphQLQuery(
            "query GetProduct(\$id: ID!) { product(id: \$id) { id name sku } }",
            mapOf("id" to "1")
        )

        val request = HttpRequest.POST("/graphql", query)
            .contentType(MediaType.APPLICATION_JSON)
        
        httpClient.exchangeAsString(request)
          .shouldBeSuccessful()
          .shouldBeJson()
    }

    @Test
    @Order(6)
    fun `should handle invalid GraphQL query`() {
        val invalidQuery = mapOf(
            "query" to "invalid query syntax { products { id name }"
        )

        val request = HttpRequest.POST("/graphql", invalidQuery)
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()

        val body = response.body.get()
        assertThat(body).contains("errors")
    }

    @Test
    @Order(7)
    fun `should handle GraphQL query with invalid variable types`() {
        val query = TestDataBuilders.graphQLQuery(
            "query GetProduct(\$id: ID!) { product(id: \$id) { id name sku } }",
            mapOf("id" to 123) // Wrong type - should be string
        )

        val request = HttpRequest.POST("/graphql", query)
            .contentType(MediaType.APPLICATION_JSON)
        
        httpClient.exchangeAsString(request)
          .shouldBeSuccessful()
          .shouldBeJson()
    }

    @Test
    @Order(8)
    fun `should handle GraphQL mutation with validation errors`() {
        val mutation = TestDataBuilders.createProductMutation(
            name = "", // Empty name should be invalid
            sku = "INVALID-SKU",
            priceCents = -100L, // Negative price should be invalid
            stock = -5 // Negative stock should be invalid
        )

        val request = HttpRequest.POST("/graphql", mutation)
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()

        val body = response.body.get()
        assertThat(body).contains("errors")
    }

    @Test
    @Order(9)
    fun `should handle GraphQL introspection query`() {
        val introspectionQuery = mapOf(
            "query" to """
                query IntrospectionQuery {
                    __schema {
                        queryType { name }
                        mutationType { name }
                        subscriptionType { name }
                        types {
                            ...FullType
                        }
                    }
                }
                fragment FullType on __Type {
                    kind
                    name
                    description
                }
            """.trimIndent()
        )

        val request = HttpRequest.POST("/graphql", introspectionQuery)
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
          .shouldHaveNonEmptyBody()

        val body = response.body.get()
        assertThat(body).contains("__schema")
    }

    @Test
    @Order(10)
    fun `should handle GraphQL query without content type`() {
        val query = TestDataBuilders.productsQuery()
        val request = HttpRequest.POST("/graphql", query)
        
        val response = httpClient.exchangeAsString(request)
        // Should either work or return 415 for unsupported media type
        assertThat(response.status.code).isIn(200, 415)
    }

    @Test
    @Order(11)
    fun `should handle empty GraphQL request`() {
        val emptyRequest = mapOf<String, Any>()
        val request = HttpRequest.POST("/graphql", emptyRequest)
            .contentType(MediaType.APPLICATION_JSON)
        
        val exception = assertThrows<HttpClientResponseException> {
            httpClient.exchangeAsString(request)
        }
        assert(exception.status == HttpStatus.BAD_REQUEST)
    }

    // ========== ENTERPRISE-GRADE TESTS ==========

    @Test
    @Order(12)
    @Timeout(value = 5, unit = TimeUnit.SECONDS)
    fun `should handle concurrent GraphQL mutations`() {
        val sku = uniqueSku()
        val mutation = TestDataBuilders.createProductMutation(
            name = uniqueName(),
            sku = sku,
            priceCents = 1000L,
            stock = 5
        )

        // Test race conditions with concurrent mutations
        val futures = (1..10).map { 
            CompletableFuture.supplyAsync {
                try {
                    httpClient.exchangeAsString(
                        HttpRequest.POST("/graphql", mutation)
                            .contentType(MediaType.APPLICATION_JSON)
                    )
                } catch (e: HttpClientResponseException) {
                    e
                }
            }
        }
        
        val results = futures.map { it.get() }
        val successful = results.count { it is String && it.contains("data") }
        val conflicts = results.count { it is HttpClientResponseException }
        
        assertThat(successful).isEqualTo(1)
        assertThat(conflicts).isEqualTo(9)
    }

    @Test
    @Order(13)
    fun `should handle large GraphQL payloads`() {
        val largeMutation = TestDataBuilders.createProductMutation(
            name = "A".repeat(1000), // Test field length limits
            sku = uniqueSku(),
            priceCents = 1000L,
            stock = 5
        )

        val request = HttpRequest.POST("/graphql", largeMutation)
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
    }

    @Test
    @Order(14)
    fun `should handle GraphQL query depth limits`() {
        val deepQuery = """
            query {
                products {
                    id
                    name
                    customers {
                        id
                        name
                        products {
                            id
                            name
                            customers {
                                id
                                name
                            }
                        }
                    }
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf("query" to deepQuery))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
    }

    @Test
    @Order(15)
    fun `should handle GraphQL query complexity limits`() {
        val complexQuery = """
            query {
                products {
                    id
                    name
                    sku
                    priceCents
                    stock
                    createdAt
                    updatedAt
                }
                customers {
                    id
                    name
                    email
                    status
                    createdAt
                    updatedAt
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf("query" to complexQuery))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
          .shouldHaveNonEmptyBody()
    }

    @Test
    @Order(16)
    fun `should handle GraphQL subscription queries`() {
        val subscriptionQuery = """
            subscription {
                productUpdated {
                    id
                    name
                    sku
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf("query" to subscriptionQuery))
            .contentType(MediaType.APPLICATION_JSON)
        
        // GraphQL subscriptions might return different status codes
        val response = httpClient.exchangeAsString(request)
        assertThat(response.status.code).isIn(200, 400, 501) // 501 if not implemented
    }

    @Test
    @Order(17)
    fun `should handle GraphQL batch requests`() {
        val batchRequest = listOf(
            mapOf("query" to TestDataBuilders.productsQuery()),
            mapOf("query" to TestDataBuilders.customersQuery())
        )

        val request = HttpRequest.POST("/graphql", batchRequest)
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
    }

    @Test
    @Order(18)
    fun `should handle GraphQL query with fragments`() {
        val queryWithFragments = """
            query {
                products {
                    ...ProductFields
                }
                customers {
                    ...CustomerFields
                }
            }
            
            fragment ProductFields on Product {
                id
                name
                sku
                priceCents
            }
            
            fragment CustomerFields on Customer {
                id
                name
                email
                status
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf("query" to queryWithFragments))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
          .shouldHaveNonEmptyBody()
    }

    @Test
    @Order(19)
    fun `should handle GraphQL query with aliases`() {
        val queryWithAliases = """
            query {
                allProducts: products {
                    id
                    name
                }
                activeCustomers: customers {
                    id
                    name
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf("query" to queryWithAliases))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
          .shouldHaveNonEmptyBody()
    }

    @Test
    @Order(20)
    fun `should handle GraphQL query with directives`() {
        val queryWithDirectives = """
            query {
                products @include(if: true) {
                    id
                    name
                }
                customers @skip(if: false) {
                    id
                    name
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf("query" to queryWithDirectives))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
    }

    @Test
    @Order(21)
    fun `should handle GraphQL query with union types`() {
        val queryWithUnions = """
            query {
                searchResults {
                    ... on Product {
                        id
                        name
                        sku
                    }
                    ... on Customer {
                        id
                        name
                        email
                    }
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf("query" to queryWithUnions))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        // This might return an error if union types aren't implemented
        assertThat(response.status.code).isIn(200, 400)
    }

    @Test
    @Order(22)
    fun `should handle GraphQL query with interface types`() {
        val queryWithInterfaces = """
            query {
                entities {
                    id
                    name
                    ... on Product {
                        sku
                        priceCents
                    }
                    ... on Customer {
                        email
                        status
                    }
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf("query" to queryWithInterfaces))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        // This might return an error if interface types aren't implemented
        assertThat(response.status.code).isIn(200, 400)
    }

    @Test
    @Order(23)
    fun `should handle GraphQL query with enums`() {
        val queryWithEnums = """
            query {
                customers {
                    id
                    name
                    status
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf("query" to queryWithEnums))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
    }

    @Test
    @Order(24)
    fun `should handle GraphQL query with custom scalars`() {
        val queryWithCustomScalars = """
            query {
                products {
                    id
                    name
                    createdAt
                    updatedAt
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf("query" to queryWithCustomScalars))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
    }

    @Test
    @Order(25)
    fun `should handle GraphQL query with input types`() {
        val queryWithInputTypes = """
            query {
                products(filter: { name: "test", priceMin: 100, priceMax: 1000 }) {
                    id
                    name
                    priceCents
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf("query" to queryWithInputTypes))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        // This might return an error if input types aren't implemented
        assertThat(response.status.code).isIn(200, 400)
    }

    @Test
    @Order(26)
    fun `should handle GraphQL query with non-null fields`() {
        val queryWithNonNullFields = """
            query {
                products {
                    id!
                    name!
                    sku!
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf("query" to queryWithNonNullFields))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
    }

    @Test
    @Order(27)
    fun `should handle GraphQL query with list fields`() {
        val queryWithListFields = """
            query {
                products {
                    id
                    name
                    tags
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf("query" to queryWithListFields))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        // This might return an error if list fields aren't implemented
        assertThat(response.status.code).isIn(200, 400)
    }

    @Test
    @Order(28)
    fun `should handle GraphQL query with nested fields`() {
        val queryWithNestedFields = """
            query {
                products {
                    id
                    name
                    category {
                        id
                        name
                        description
                    }
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf("query" to queryWithNestedFields))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        // This might return an error if nested fields aren't implemented
        assertThat(response.status.code).isIn(200, 400)
    }

    @Test
    @Order(29)
    fun `should handle GraphQL query with multiple operations`() {
        val queryWithMultipleOperations = """
            query GetProducts {
                products {
                    id
                    name
                }
            }
            
            query GetCustomers {
                customers {
                    id
                    name
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf("query" to queryWithMultipleOperations))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        // This might return an error if multiple operations aren't supported
        assertThat(response.status.code).isIn(200, 400)
    }

    @Test
    @Order(30)
    fun `should handle GraphQL query with operation name`() {
        val queryWithOperationName = """
            query GetProducts {
                products {
                    id
                    name
                }
            }
            
            query GetCustomers {
                customers {
                    id
                    name
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf(
            "query" to queryWithOperationName,
            "operationName" to "GetProducts"
        ))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
    }

    @Test
    @Order(31)
    fun `should handle GraphQL query with variables and operation name`() {
        val queryWithVariablesAndOperationName = """
            query GetProduct(${'$'}id: ID!) {
                product(id: ${'$'}id) {
                    id
                    name
                    sku
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf(
            "query" to queryWithVariablesAndOperationName,
            "operationName" to "GetProduct",
            "variables" to mapOf("id" to "1")
        ))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
    }

    @Test
    @Order(32)
    fun `should handle GraphQL query with invalid operation name`() {
        val queryWithInvalidOperationName = """
            query GetProducts {
                products {
                    id
                    name
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf(
            "query" to queryWithInvalidOperationName,
            "operationName" to "NonExistentOperation"
        ))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
          .shouldHaveErrors()
    }

    @Test
    @Order(33)
    fun `should handle GraphQL query with invalid variables`() {
        val queryWithInvalidVariables = """
            query GetProduct(${'$'}id: ID!) {
                product(id: ${'$'}id) {
                    id
                    name
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf(
            "query" to queryWithInvalidVariables,
            "variables" to mapOf("id" to 123) // Wrong type
        ))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
        
        val body = response.body.get()
        assertThat(body).contains("errors")
    }

    @Test
    @Order(34)
    fun `should handle GraphQL query with missing required variables`() {
        val queryWithMissingVariables = """
            query GetProduct(${'$'}id: ID!) {
                product(id: ${'$'}id) {
                    id
                    name
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf(
            "query" to queryWithMissingVariables
            // Missing variables
        ))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
        
        val body = response.body.get()
        assertThat(body).contains("errors")
    }

    @Test
    @Order(35)
    fun `should handle GraphQL query with extra variables`() {
        val queryWithExtraVariables = """
            query GetProducts {
                products {
                    id
                    name
                }
            }
        """.trimIndent()

        val request = HttpRequest.POST("/graphql", mapOf(
            "query" to queryWithExtraVariables,
            "variables" to mapOf("extra" to "value")
        ))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
    }

    @Test
    @Order(36)
    fun `should handle GraphQL query with invalid JSON`() {
        val request = HttpRequest.POST("/graphql", "invalid json")
            .contentType(MediaType.APPLICATION_JSON)
        
        val exception = assertThrows<HttpClientResponseException> {
            httpClient.exchangeAsString(request)
        }
        assert(exception.status == HttpStatus.BAD_REQUEST)
    }

    @Test
    @Order(37)
    fun `should handle GraphQL query with malformed JSON`() {
        val request = HttpRequest.POST("/graphql", "{ invalid json }")
            .contentType(MediaType.APPLICATION_JSON)
        
        val exception = assertThrows<HttpClientResponseException> {
            httpClient.exchangeAsString(request)
        }
        assert(exception.status == HttpStatus.BAD_REQUEST)
    }

    @Test
    @Order(38)
    fun `should handle GraphQL query with empty query string`() {
        val request = HttpRequest.POST("/graphql", mapOf("query" to ""))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
        
        val body = response.body.get()
        assertThat(body).contains("errors")
    }

    @Test
    @Order(39)
    fun `should handle GraphQL query with null query`() {
        val request = HttpRequest.POST("/graphql", mapOf("query" to null))
            .contentType(MediaType.APPLICATION_JSON)
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
        
        val body = response.body.get()
        assertThat(body).contains("errors")
    }

    @Test
    @Order(40)
    fun `should handle GraphQL query with invalid content type`() {
        val request = HttpRequest.POST("/graphql", TestDataBuilders.productsQuery())
            .contentType(MediaType.TEXT_PLAIN)
        
        val exception = assertThrows<HttpClientResponseException> {
            httpClient.exchangeAsString(request)
        }
        assert(exception.status == HttpStatus.UNSUPPORTED_MEDIA_TYPE)
    }

    @Test
    @Order(41)
    fun `should handle GraphQL query with custom headers`() {
        val request = HttpRequest.POST("/graphql", TestDataBuilders.productsQuery())
            .contentType(MediaType.APPLICATION_JSON)
            .header("X-Custom-Header", "custom-value")
            .header("Authorization", "Bearer test-token")
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
    }

    @Test
    @Order(42)
    fun `should handle GraphQL query with rate limiting`() {
        val query = TestDataBuilders.productsQuery()
        
        // Send multiple requests quickly to test rate limiting
        repeat(100) {
            val request = HttpRequest.POST("/graphql", query)
                .contentType(MediaType.APPLICATION_JSON)
            
            try {
                httpClient.exchangeAsString(request)
            } catch (e: HttpClientResponseException) {
                if (e.status == HttpStatus.TOO_MANY_REQUESTS) {
                    // Rate limit hit - this is expected behavior
                    return
                }
            }
        }
    }

    @Test
    @Order(43)
    fun `should handle GraphQL query with timeout`() {
        val query = TestDataBuilders.productsQuery()
        
        val request = HttpRequest.POST("/graphql", query)
            .contentType(MediaType.APPLICATION_JSON)
            .header("X-Timeout", "1000") // 1 second timeout
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
    }

    @Test
    @Order(44)
    fun `should handle GraphQL query with caching headers`() {
        val query = TestDataBuilders.productsQuery()
        
        val request = HttpRequest.POST("/graphql", query)
            .contentType(MediaType.APPLICATION_JSON)
            .header("Cache-Control", "no-cache")
            .header("If-None-Match", "etag-value")
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
    }

    @Test
    @Order(45)
    fun `should handle GraphQL query with compression`() {
        val query = TestDataBuilders.productsQuery()
        
        val request = HttpRequest.POST("/graphql", query)
            .contentType(MediaType.APPLICATION_JSON)
            .header("Accept-Encoding", "gzip, deflate")
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
    }

    @Test
    @Order(46)
    fun `should handle GraphQL query with different HTTP methods`() {
        val query = TestDataBuilders.productsQuery()
        
        // Test GET request
        val getRequest = HttpRequest.GET<Any>("/graphql?query=${query}")
        val getResponse = httpClient.exchangeAsString(getRequest)
        assertThat(getResponse.status.code).isIn(200, 405) // 405 if GET not supported
        
        // Test PUT request
        val putRequest = HttpRequest.PUT("/graphql", query)
            .contentType(MediaType.APPLICATION_JSON)
        val putResponse = httpClient.exchangeAsString(putRequest)
        assertThat(putResponse.status.code).isIn(200, 405) // 405 if PUT not supported
    }

    @Test
    @Order(47)
    fun `should handle GraphQL query with different content types`() {
        val query = TestDataBuilders.productsQuery()
        
        // Test with different content types
        val contentTypes = listOf(
            MediaType.APPLICATION_JSON,
            MediaType.APPLICATION_JSON_TYPE,
            MediaType("application", "graphql+json")
        )
        
        contentTypes.forEach { contentType ->
            val request = HttpRequest.POST("/graphql", query)
                .contentType(contentType)
            
            try {
                val response = httpClient.exchangeAsString(request)
                response.shouldBeSuccessful()
            } catch (e: HttpClientResponseException) {
                // Some content types might not be supported
                assertThat(e.status).isIn(HttpStatus.UNSUPPORTED_MEDIA_TYPE, HttpStatus.BAD_REQUEST)
            }
        }
    }

    @Test
    @Order(48)
    fun `should handle GraphQL query with different encodings`() {
        val query = TestDataBuilders.productsQuery()
        
        val request = HttpRequest.POST("/graphql", query)
            .contentType(MediaType.APPLICATION_JSON)
            .header("Content-Encoding", "utf-8")
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
    }

    @Test
    @Order(49)
    fun `should handle GraphQL query with different languages`() {
        val query = TestDataBuilders.productsQuery()
        
        val request = HttpRequest.POST("/graphql", query)
            .contentType(MediaType.APPLICATION_JSON)
            .header("Accept-Language", "en-US,en;q=0.9")
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
    }

    @Test
    @Order(50)
    fun `should handle GraphQL query with different user agents`() {
        val query = TestDataBuilders.productsQuery()
        
        val request = HttpRequest.POST("/graphql", query)
            .contentType(MediaType.APPLICATION_JSON)
            .header("User-Agent", "GraphQL-Test-Client/1.0")
        
        val response = httpClient.exchangeAsString(request)
        response
          .shouldBeSuccessful()
          .shouldBeJson()
    }
}
