
rootProject.name = "neotool-service"
include("app", "security")
